<?php





include_once  plugin_dir_path(IRE_PLUGIN_FILE) . './utils/modals/helper.php';

include_once  plugin_dir_path(IRE_PLUGIN_FILE) . './utils/modals/project.php';

include_once  plugin_dir_path(IRE_PLUGIN_FILE) . './utils/modals/floor.php';

include_once  plugin_dir_path(IRE_PLUGIN_FILE) . './utils/modals/block.php';

include_once  plugin_dir_path(IRE_PLUGIN_FILE) . './utils/modals/flat.php';

include_once  plugin_dir_path(IRE_PLUGIN_FILE) . './utils/modals/type.php';

include_once  plugin_dir_path(IRE_PLUGIN_FILE) . './utils/modals/meta.php';

include_once  plugin_dir_path(IRE_PLUGIN_FILE) . './utils/modals/shortCodeApi.php';

include_once  plugin_dir_path(IRE_PLUGIN_FILE) . './utils/modals/tooltip.php';
